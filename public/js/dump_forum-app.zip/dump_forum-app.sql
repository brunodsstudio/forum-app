-- --------------------------------------------------------
-- Servidor:                     localhost
-- Versão do servidor:           10.4.11-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para forum-app
CREATE DATABASE IF NOT EXISTS `forum-app` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `forum-app`;

-- Copiando estrutura para tabela forum-app.comment
DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_user_id_foreign` (`user_id`),
  CONSTRAINT `comment_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.comment: ~4 rows (aproximadamente)
DELETE FROM `comment`;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`id`, `description`, `deleted`, `created_at`, `updated_at`, `user_id`, `post_id`) VALUES
	(1, 'Muito Legal essa postagem', 0, '2022-02-11 00:28:55', '2022-02-11 00:28:58', 3, 1),
	(2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud', 0, '2022-02-11 00:30:43', '2022-02-11 00:30:44', 1, 6),
	(3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud', 0, '2022-02-11 00:36:27', '2022-02-11 00:36:28', 3, 5),
	(4, 'hjkdfdsfh dsakjfhsdfkjhds dsjkfhsdkjfh', 0, '2022-02-11 00:53:56', '2022-02-11 00:53:57', 3, 5),
	(5, 'Esse não pode ser deletado', 0, '2022-02-11 03:35:40', '2022-02-11 03:35:40', 2, 6),
	(18, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 0, '2022-02-11 14:34:44', '2022-02-11 14:34:44', 1, 1),
	(19, 'uyhdsygfjhg hdsfhjjhgk kjhsdadkhjgds', 0, '2022-02-11 16:15:19', '2022-02-11 16:15:19', 1, 7),
	(20, 'tess hasdgfyasd tdafdsfk hkdfjhds', 0, '2022-02-11 21:21:24', '2022-02-11 21:21:24', 1, 12),
	(23, 'Email teste', 0, '2022-02-11 21:39:58', '2022-02-11 21:39:58', 1, 12),
	(24, 'teste de email gmail', 0, '2022-02-11 22:11:56', '2022-02-11 22:11:56', 1, 12),
	(25, 'teste de email gmail', 0, '2022-02-11 22:12:36', '2022-02-11 22:12:36', 1, 12),
	(26, 'teste de email gmail', 0, '2022-02-11 22:13:56', '2022-02-11 22:13:56', 1, 12);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.failed_jobs: ~0 rows (aproximadamente)
DELETE FROM `failed_jobs`;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.likeviews
DROP TABLE IF EXISTS `likeviews`;
CREATE TABLE IF NOT EXISTS `likeviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `views` int(10) unsigned NOT NULL,
  `likes` int(10) unsigned NOT NULL,
  `deslikes` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.likeviews: ~0 rows (aproximadamente)
DELETE FROM `likeviews`;
/*!40000 ALTER TABLE `likeviews` DISABLE KEYS */;
INSERT INTO `likeviews` (`id`, `views`, `likes`, `deslikes`, `user_id`, `post_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, 0, 1, 1, '2022-02-11 01:36:57', '2022-02-11 01:36:58'),
	(2, 1, 1, 0, 3, 1, '2022-02-11 02:22:35', '2022-02-11 02:22:35');
/*!40000 ALTER TABLE `likeviews` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.migrations: ~9 rows (aproximadamente)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2022_02_09_210057_user_profile', 2),
	(6, '2022_02_09_210137_user_friends', 2),
	(7, '2022_02_09_210608_user_friends2', 3),
	(8, '2022_02_10_143912_post', 4),
	(9, '2022_02_10_152826_comment', 5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.password_resets: ~0 rows (aproximadamente)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.personal_access_tokens
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.personal_access_tokens: ~0 rows (aproximadamente)
DELETE FROM `personal_access_tokens`;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.post
DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `post_image` blob DEFAULT NULL,
  `post_type` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `master_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_user_id_foreign` (`user_id`),
  CONSTRAINT `post_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.post: ~5 rows (aproximadamente)
DELETE FROM `post`;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`id`, `title`, `description`, `status`, `post_image`, `post_type`, `master_id`, `created_at`, `updated_at`, `user_id`) VALUES
	(1, 'PPrimeiro Post', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 1, _binary 0x2F696D616765732F3030303030302E706E67, '', 0, '2022-02-10 22:20:55', '2022-02-10 22:20:56', 1),
	(3, 'Segunfo Post', 'kjsdhsdjkhsfdjfhdskjh sfgfdgdfgfdsgdfg sdfsdafsdaf', 1, _binary 0x2F696D616765732F3030303030302E706E67, '', 0, '2022-02-10 22:20:56', '2022-02-10 22:20:57', 1),
	(4, 'Segundo Post', 'Edição do Segundo Post asdasd asdsad asdas', 1, _binary 0x2F696D616765732F3030303030302E706E67, 'Edit', 3, '2022-02-10 22:21:36', '2022-02-10 22:21:37', 1),
	(5, 'Segundo Post', '2º Edição do Segundo Post asdasd asdsad asdas', 1, _binary 0x2F696D616765732F3030303030302E706E67, 'Edit', 3, '2022-02-10 22:22:11', '2022-02-10 22:22:11', 1),
	(6, 'Primeiro post de amigo', 'Poste de amigo', 1, _binary 0x2F696D616765732F3030303030302E706E67, 'Master', 0, '2022-02-10 22:36:11', '2022-02-10 22:36:11', 3),
	(7, 'fdsfdsfdsf dsafdsfdsf dsfdsfds', 'dsfdsfdsfdsfdsfdsffv gdsffgdsgsdagsasadfsafd', 1, _binary 0x2F696D616765732F506F7374496D616765732F4B45464C412E6A7067, 'Master', 0, '2022-02-11 16:14:38', '2022-02-11 16:14:38', 1),
	(10, 'PPrimeiro Post', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nteste', 1, _binary 0x2F696D616765732F3030303030302E706E67, 'Edit', 1, '2022-02-11 21:09:38', '2022-02-11 21:09:38', 1),
	(11, 'Blade Runner 2099: Ridley Scott Set to Produce Live-Action Sequel Series at Amazon', 'Amazon Studios has officially announced that a live-action small-screen spin-off of the Blade Runner franchise is currently in development. The series is said to be a direct sequel to Denis Villeneuves Blade Runner 2049, which was a follow-up to Ridley Scotts original 1982 cult classic. Scott is serving as an executive producer on this new series, which will be backed by his production company Scott Free Productions. Silka Luisa, who will act as showrunner on the upcoming Elisabeth Moss vehicle Shining Girls, will write and executive produce the first live-action Blade Runner television series.', 1, _binary 0x2F696D616765732F506F7374496D616765732F626C6164652D72756E6E65722D736F6369616C2D66656174757265642E6A7067, 'Master', 0, '2022-02-11 21:16:48', '2022-02-11 21:16:48', 1),
	(12, 'Tom Hanks A Man Called Otto Sells to Sony in Record EFM Deal Worth $60 Million', 'Americas Dad Tom Hanks is really cranking out those dad movies out, isnt he? His latest, an adaptation of the bestselling Swedish novel A Man Called Ove—the movie is titled A Man Called Otto—has sold to Sony in a record European Film Market deal valued at around $60 million, Deadline reports.', 1, _binary 0x2F696D616765732F506F7374496D616765732F746F6D2D68616E6B732D736F6369616C2E6A7067, 'Master', 0, '2022-02-11 21:20:41', '2022-02-11 21:20:41', 3);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.users: ~3 rows (aproximadamente)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Bruno de Lima', 'brunodsstudio@gmail.com', NULL, '$2y$10$.L/6P4SUfBjAhuUpSpdZHOI23VVJ5MCLHnaT2gNXwggdsAh5Gbav2', NULL, '2022-02-09 21:16:53', '2022-02-09 21:16:53'),
	(2, 'A Era Nerd', 'imprensa@aeranerd.com.br', NULL, '$2y$10$ZwwlbwbZn4.rNVcp6aF.zevaonAB2ff3frFXp/7DnxRpEVm968ZUu', NULL, '2022-02-11 00:49:49', '2022-02-11 00:49:49'),
	(3, 'Maria mariana', 'maria@qqercoisa.com.br', NULL, '$2y$10$.L/6P4SUfBjAhuUpSpdZHOI23VVJ5MCLHnaT2gNXwggdsAh5Gbav2', NULL, '2022-02-11 00:51:14', '2022-02-11 00:51:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.users_friends
DROP TABLE IF EXISTS `users_friends`;
CREATE TABLE IF NOT EXISTS `users_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `friend_id` int(10) unsigned NOT NULL,
  `accepted_at` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_friends_user_id_foreign` (`user_id`),
  CONSTRAINT `users_friends_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.users_friends: ~1 rows (aproximadamente)
DELETE FROM `users_friends`;
/*!40000 ALTER TABLE `users_friends` DISABLE KEYS */;
INSERT INTO `users_friends` (`id`, `friend_id`, `accepted_at`, `status`, `created_at`, `updated_at`, `user_id`) VALUES
	(1, 3, '2022-02-10', 1, '2022-02-10 22:10:53', '2022-02-10 22:10:54', 1);
/*!40000 ALTER TABLE `users_friends` ENABLE KEYS */;

-- Copiando estrutura para tabela forum-app.users_profile
DROP TABLE IF EXISTS `users_profile`;
CREATE TABLE IF NOT EXISTS `users_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` blob DEFAULT NULL,
  `phone` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_profile_user_id_foreign` (`user_id`),
  CONSTRAINT `users_profile_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela forum-app.users_profile: ~2 rows (aproximadamente)
DELETE FROM `users_profile`;
/*!40000 ALTER TABLE `users_profile` DISABLE KEYS */;
INSERT INTO `users_profile` (`id`, `site`, `profile_image`, `phone`, `age`, `gender`, `description`, `created_at`, `updated_at`, `user_id`) VALUES
	(1, 'www.aeranerd.com.brfghfg', _binary 0x2F696D616765732F70726F66696C65506963732F4453435F303933372E4A5047, '1997102909366', 55, 'M', 'Oie sou Bruno gfhfgh', '2022-02-10 12:48:10', '2022-02-10 12:47:27', 1),
	(2, NULL, _binary 0x2F696D616765732F70726F66696C65506963732F647265616D636174636865722D666163652D6A6577656C732D666163652D6A6577656C72792D2D6D772D3133383438312D322E6A7067, NULL, NULL, NULL, 'Complete seu perfil', '2022-02-11 03:34:16', '2022-02-11 03:34:15', 3),
	(4, NULL, _binary 0x2F696D616765732F70726F66696C65506963732F2F4C6F676F526F756E642E6A7067, NULL, NULL, NULL, NULL, '2022-02-11 03:34:14', '2022-02-11 03:34:14', 2);
/*!40000 ALTER TABLE `users_profile` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
